cd tiff-4.0.4
export LLVM_CONFIG="llvm-config-11"
CC=afl-clang-lto ./configure  --disable-shared
AFL_USE_ASAN=1 make -j4
AFL_USE_ASAN=1 make install