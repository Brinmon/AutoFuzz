echo "开始编译"
cd fuzzgoat
AFL_USE_ASAN=1 make 
make install